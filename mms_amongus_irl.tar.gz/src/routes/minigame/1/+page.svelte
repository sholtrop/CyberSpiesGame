<script>
  import Wiretap from "$lib/minigames/Wiretap.svelte";
</script>

<Wiretap />
