<script>
  import Password from "$lib/minigames/Password.svelte";
</script>

<Password />
