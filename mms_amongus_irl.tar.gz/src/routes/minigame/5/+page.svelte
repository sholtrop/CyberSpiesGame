<script lang="ts">
  import SumToHundred from "$lib/minigames/SumToHundred.svelte";
</script>

<SumToHundred />
