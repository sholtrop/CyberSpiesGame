<script>
  import DeleteEvidence from "$lib/minigames/DeleteEvidence.svelte";
</script>

<DeleteEvidence />
