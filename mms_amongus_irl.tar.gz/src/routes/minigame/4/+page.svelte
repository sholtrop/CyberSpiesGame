<script>
  import Virus from "$lib/minigames/Virus.svelte";
</script>

<Virus />
