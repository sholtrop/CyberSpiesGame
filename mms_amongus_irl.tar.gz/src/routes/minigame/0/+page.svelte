<script lang="ts">
  import SimonSays from "$lib/minigames/SimonSays.svelte";
</script>

<SimonSays />
