<script>
  import Mining from "$lib/minigames/Mining.svelte";
</script>

<Mining />
