<script lang="ts">

</script>

<div>
    <p>You are dead.</p>
</div>