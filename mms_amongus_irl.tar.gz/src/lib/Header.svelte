<h1 class="text-2xl mb-3 text-center"><slot /></h1>
