<h1 class="font-bold text-lg">Game Rules</h1>
<ul class="list-disc w-full px-6 space-y-6 leading-tight mt-6">
  <li>
    Majority of players will be <b>Cyber Criminals</b>. They must complete tasks
    to fill the task bar.
  </li>
  <li>
    Against them are <b>Secret Agents</b>, who must eliminate the criminals.
  </li>

  <li>
    Everyone can call <b>emergency meetings</b> at the meeting point by scanning
    its NFC tag and pressing the button
  </li>
  <li>
    If someone close to you wants to scan your NFC tag, let them. Don't run
    away.
  </li>
  <li>Talking is not allowed while dead.</li>
  <li>
    If you are killed, sit or lie on the floor on the spot where you died.
  </li>
</ul>
