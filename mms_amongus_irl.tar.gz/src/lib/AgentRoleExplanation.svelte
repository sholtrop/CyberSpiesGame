<h1 class="font-bold text-lg">Secret Agents</h1>
<ul class="list-disc w-full px-6 space-y-6 leading-tight mt-6">
  <li>Win by killing all the cyber criminals</li>
  <li>
    <b>Kill a cyber criminal</b> by scanning the NFC tag on their right or left shoulder
  </li>
  <li>
    Get a list of <b>fake tasks</b> in order to blend in. Press a task for a certain
    amount of time and you can mark it as completed.
  </li>
  <li>
    Can <b>report dead bodies</b> and <b>call emergency meetings</b>, same as
    cyber criminals.
  </li>
  <li>
    Get a special screen that shows everyone's status and allows the use of
    sabotages
  </li>
  <li>
    <b>Sabotages</b> can slow down and isolate cyber criminals
  </li>
</ul>
